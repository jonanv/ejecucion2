<?php  


echo "DEPARTAMENTO: ".$_SESSION['Ndepartamento']." - MUNICIPIO: ".$_SESSION['Nmunicipio'];

?>