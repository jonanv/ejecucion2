<?php

mysql_connect("localhost", "javo", "Reparto2020*");
mysql_select_db("ofijudi2020");

?>