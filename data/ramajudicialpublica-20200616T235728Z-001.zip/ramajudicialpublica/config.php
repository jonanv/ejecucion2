<?php
$config = Config::singleton();

$config->set('controllersFolder', 'controllers/');
$config->set('modelsFolder', 'models/');
$config->set('viewsFolder', 'views/');

$config->set('dbhost', 'localhost');
$config->set('dbname', 'ofijudi2020');
$config->set('dbuser', 'javo');
$config->set('dbpass', 'Reparto2020*');

define('titulo',' - Rama Judicial Publica -'); 
define('rutabase','/ramajudicialpublica/'); 


?>