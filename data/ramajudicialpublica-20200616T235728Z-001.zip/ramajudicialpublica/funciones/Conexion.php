<?php

$dbhost           ='localhost';
$dbusername       ='javo';
$dbuserpassword   ='Reparto2020*';
$dbdefault_dbname ='ofijudi2020';

function db_connect(){

	global $dbhost, $dbusername, $dbuserpassword, $dbdefault_dbname;
	
	$link = mysql_connect($dbhost, $dbusername, $dbuserpassword);

	if(!$link){
		echo "Fallo en la Conexi�n al host $dbhost";
		return 0;
	}
	else if(empty($dbname) && !mysql_select_db($dbdefault_dbname)){
		echo "Fallo en la Conexi�n al host $dbhost";
		return 0;
	}
	else return $link;
}
?>

