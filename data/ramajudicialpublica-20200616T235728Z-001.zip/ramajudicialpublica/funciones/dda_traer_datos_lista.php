<?php

session_start(); 

if($_SESSION['id']!=""){

	require_once('../libs/Conexion_Funciones.php');

	$id		= trim($_GET['id']);
	$idsql	= trim($_GET['idsql']);
	$idtm	= trim($_GET['idtm']);
	
	$idusuario  = $_SESSION['idUsuario'];
	
	
	$conexion = db_connect();
	
	if($idsql == 1){
		
		$sql = "SELECT * FROM dda_municipio 
		        WHERE iddpto = '$id' 
				ORDER BY des";
				
		echo '<option value="">Seleccionar Municipio</option>';
	}
	
	if($idsql == 2){
		
		$sql = "SELECT * FROM dda_especialidad 
		        WHERE identida = '$id' 
				ORDER BY des";
				
		echo '<option value="">Seleccionar Especialidad</option>';
	}
	
	
	$resultado = mysql_query($sql);
	

   	while($fila = mysql_fetch_array($resultado)){
	
		if($idsql == 1){
			
			echo '<option value="'.trim($fila['id']).'">'.$fila['des'].'</option>';
		}
		
		if($idsql == 2){
			
			echo '<option value="'.trim($fila['id']).'">'.$fila['des'].'</option>';
		}
		
	
   	}
	
	mysql_close($conexion);

}
	
?>
   

	

	
	