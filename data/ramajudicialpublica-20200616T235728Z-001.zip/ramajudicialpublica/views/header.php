<div id="sliderWrap">
		<div id="openCloseIdentifier"></div>
		<div id="sliderm">
			<div id="sliderContent">
		<div id="sliderop"></div>			
			</div>
			<div id="openCloseWrap"></div>
		</div>
</div>
<div id="topPg">
<div id="menu"><a href="index.php?controller=index&amp;action=ruta_base"><img src="views/images/crm_menup.png" alt="Menu Principal" title="Menu Principal"/></a></div>
<div id="cerrar"><a href="index.php?controller=index&amp;action=close_session"><img src="views/images/crm_exit.png" alt="Cerrar Sesion" title="Cerrar Sesion"/></a></div>
</div>