<?php
session_start();
//error_reporting(0); 
require 'libs/frontController.php';
frontController::main();
?>