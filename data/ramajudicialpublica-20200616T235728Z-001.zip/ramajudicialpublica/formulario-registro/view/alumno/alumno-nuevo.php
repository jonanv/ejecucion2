<center>
<h3 class="page-header">
    <?php //echo $alm->__GET('id') != null ? $alm->__GET('nombre_usuario') : 'REGISTRO USUARIO'; ?>
	<br>
	RAMA JUDICIAL DEL PODER PÚBLICO
	<br>
	DIRECCIÓN EJECUTIVA DE ADMINISTRACIÓN JUDICIAL
	<br>
	SECCIONAL CALDAS
	<br>
	<img src="view/images/logorama.png" width="300" height="100"/> 
</h3>
</center>

<!-- <ol class="breadcrumb">
  <li><a href="?c=Alumno">Alumnos</a></li>
  <li class="active">Registro Usuario</li>
</ol> -->

<div class="btn-toolbar" role="toolbar">

  <a href="?c=Alumno&a=Ramapublica" title="Regresar">
  
	  <button type="button" class="btn btn-default">
		<span class="glyphicon glyphicon-arrow-left"></span>Regresar
	  </button>
  
  </a>

</div>

<center><h3 class="page-header">REGISTRAR USUARIO / PLATAFORMA WEB RAMAJUDICIALPUBLICA</h3></center>


<form id="frm-alumno" action="?c=Alumno&a=CrearMultiple" method="post" enctype="multipart/form-data">
    
    <div id="alumnos" class="row">
<div id="lo-que-vamos-a-copiar">
    <div class="col-xs-4">
        <div class="well well-sm">
		
            <div class="form-group">
                <label>Usuario (Sin espacios,Tildes y Nombres Cortos)</label><br>
                <input type="text" name="nombre_usuario[]" class="form-control" placeholder="Ingrese su Usuario" data-validacion-tipo="requerido" />
            </div>

            <div class="form-group">
                <label>Contraseña</label>
                <input type="password" name="contrasena[]" class="form-control" placeholder="Ingrese su Contraseña" data-validacion-tipo="requerido"  value="<?php echo $contrasena; ?>"/>
            </div>
			
			<div class="form-group">
                <label>Nombre Completo</label>
                <input type="text" name="empleado[]" class="form-control" placeholder="Ingrese su Nombre Completo" data-validacion-tipo="requerido" value="<?php echo $empleado; ?>"/>
            </div>

        </div>
    </div>            
</div>

<!-- <div class="col-xs-4">
    <div class="well">
        <button id="btn-alumno-agregar" class="btn btn-lg btn-block btn-default" type="button">Agregar</button>                
    </div>
</div> -->

    </div>
    
   
    
    <div class="text-right">
        <button class="btn btn-success btn-lg btn-block">Guardar</button>
    </div>
</form>

<script>
    $(document).ready(function(){
        
        // El formulario que queremos replicar
        var formulario_alumno = $("#lo-que-vamos-a-copiar").html();
        
// El encargado de agregar más formularios
$("#btn-alumno-agregar").click(function(){
    // Agregamos el formulario
    $("#alumnos").prepend(formulario_alumno);

    // Agregamos un boton para retirar el formulario
    $("#alumnos .col-xs-4:first .well").append('<button class="btn-danger btn btn-block btn-retirar-alumno" type="button">Retirar</button>');

    // Hacemos focus en el primer input del formulario
    $("#alumnos .col-xs-4:first .well input:first").focus();

    // Volvemos a cargar todo los plugins que teníamos, dentro de esta función esta el del datepicker assets/js/ini.js
    Plugins();
});
        
        // Cuando hacemos click en el boton de retirar
        $("#alumnos").on('click', '.btn-retirar-alumno', function(){
            $(this).closest('.col-xs-4').remove();
        })
            
        $("#frm-alumno").submit(function(){
            return $(this).validate();
        });
    })
</script>